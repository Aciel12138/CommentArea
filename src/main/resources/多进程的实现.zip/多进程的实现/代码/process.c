#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
int main(){
    int i;
    sleep(3);
    if (fork() == 0) {
        /* Program for child process */
        for (i = 1; i <1000; i++)

            printf("This is child process\n");
        sleep(1);
    }
    else {
        /* Program for father process*/
        for (i = 1; i <1000; i++)
            printf("This is parent process\n");
        sleep(1);
    }
    return 0;
}
